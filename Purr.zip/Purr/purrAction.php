<?php 
	session_start();
	$_SESSION['email'] = $email;	
	
	$email= $_POST["Email address"];
	
	if($email == "shuvratripura@yahoo.com"){
		
		header("location: purr.php");
	}else {
		header("location: purr.php");
	}
		
?>