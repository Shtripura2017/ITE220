<?php
session_start();
?>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<body>
<img src="b.png" width="100%" height="300px" align="center">
	
<style>

h1	{color: black;
	font-family: verdana;
	text-align:left; }

h4	{color: #641E16;
	font-family: forte;
	text-align:left; }

</style>
<h1>Contact Us</h1>
<p></p>
<h4> For product inquiries and shipping updates please see our contact information below.<br> Please note that our Support team is available to answer any questions you may have Monday to Friday 9AM-5PM EST. <br>We promise we'll make you smile!  **Please allow up to 48 hours for a response during the holiday season**</h4>
<p> </p> <p> </p>

<div class="container">
	<div class="row text-center">
		<img src="mail.png" alt="mail" align="center" Style="width:200px;height:100px;">
	<h5>email us : support_purr@gmail.com</h5>
	</div>
</div>

	<div class="container">
	<h4><b>Customer Care</h4> 
<hr align="left" width="20%" color="black">
<form action="contact.php" method="POST">
	<button class="btn btn-link">Contact Us</button> <p></p> 
	</form>

	<div class="btn btn-link">Shipping and Return</div><p> </p>
	<div class="btn btn-link">Privacy Policy</div><p> </p>
	<div class="btn btn-link">Secure Shipping</div><p> </p>
</div>

<div class="container">
 <form action="purrAction.php" method="POST">
 	<div class="row">
 		<h4 align="left">Newsletter</h4>
 	</div>
 	<div class="row">
 		<div class="col-md-4">
 			<input type="text" class="form-control" placeholder="Email Address"/>
 		</div>
 			<div class="col-md-4">
 					<button class="btn btn-info">Subscribe</button>
 			
</body>