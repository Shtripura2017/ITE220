<?php
session_start();
?>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">

<div class="container">
	<form action="welcome.php" method="POST">
		<div class="row text-center">
	<img src="you.jpg" class="img-circle" alt="Thank You" align="center"
	 Style="width:400px;height:300px;">
		</div>
	</div>
<br> <br>
<style>

h1	{color: #808000;
	font-family: forte;
	text-align:center; }

h3	{color: #641E16;
	font-family: forte;
	text-align:center; }

</style>
	<h1>Thank You for Subscribing</h1>
		
		<p>
	<h3>You will receive all the exciting news about Exclusive Discounts and Promotions!</h3>


	<div class="col-md-4 text-center">
		<button id="singlebutton" name="singlebutton" class="btn btn-info">Continue to Website</button>
 	</div>
 </div>
</form>
